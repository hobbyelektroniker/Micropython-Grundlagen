# Micropython Grundlagen - 5: Mengentypen: Set
 
https://youtu.be/dRgRqFrsvk0

Python ist sehr mächtig in der Verarbeitung von Mengen. Wir beginnen mit Set.

Diskussionen, Fragen und Antworten im Forum: 
https://community.hobbyelektroniker.ch/wbb/index.php?board/64

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



