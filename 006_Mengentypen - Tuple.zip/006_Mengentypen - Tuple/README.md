# Micropython Grundlagen - 6: Mengentypen: Tuple
 
https://youtu.be/Q1SCKVTBVr8

Tuple ist eine Liste von Werten, die nur erzeugt und gelesen werden kann. Bei dieser Gelegenheit werden auch noch diverse Eigenheiten der Python - Indexierung besprochen.

Diskussionen, Fragen und Antworten im Forum: https://community.hobbyelektroniker.ch/wbb/index.php?board/64

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



