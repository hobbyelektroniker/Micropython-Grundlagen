# Micropython Grundlagen 11: Globale und lokale Variablen
 
https://youtu.be/BfNH2cAWUj4

In Python gibt es keine Deklaration von Variablen. Jede Zuweisung erzeugt eine neue Variable. Deshalb sind in Python einige Spezialitäten zu beachten. 

Diskussionen, Fragen und Antworten im Forum: https://community.hobbyelektroniker.ch/wbb/index.php?board/81

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



