# Micropython Grundlagen - 3: Textformatierung
 
https://youtu.be/-scyIFO0RHY

Laaangweilig!!! Aber trotzdem notwendig! Texte und Zahlen müssen korrekt formatiert sein, um wirklich gut lesbar zu sein. Python bietet hier einige komfortable Möglichkeiten.


Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/54


Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



