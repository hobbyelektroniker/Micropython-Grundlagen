# Hallo!

namen = ("Max","Peter","Monika","Petra")

def sage_hallo(name):
    print("Hallo " + name)
    
for name in namen:
    sage_hallo(name)

print("Das war's!")


    
    