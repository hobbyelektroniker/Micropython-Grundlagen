# Micropython Grundlagen - 1: Einleitung und erste Schritte
 
https://youtu.be/rSoMa4K5bIk

Für alle, die es etwas genauer wissen möchten. Hier werden die Grundlagen der Sprache Micropython auf eine etwas systematischere Art besprochen. Keine Angst, die erste Lektion ist ganz einfach.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/50

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



