# Micropython Grundlagen 12: Micropython, ESP32 und das Multitasking
 
https://youtu.be/FguWhBjIFak

Multitasking, genauer Multithreading, erlaubt uns Arbeiten im Hintergrund auszuführen. Während unser Programm ungestört weiterläuft, kann es zum Beispiel im Hintergrund Anfragen beantworten. Das verwenden wir zum Beispiel im Webserver der Wetterstation. Obwohl die Unterstützung in Micropython etwas bescheiden ist, lässt sich mit dem _thread - Modul schon gut arbeiten. 

Diskussionen, Fragen und Antworten im Forum: https://community.hobbyelektroniker.ch/wbb/index.php?board/85

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



