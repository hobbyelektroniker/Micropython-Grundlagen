# Micropython Grundlagen 9: Bedingungen und Schleifen
 
https://youtu.be/sdhkimZUiT8

Die Ablaufsteuerung in einem Programm wird über Kontrollstrukturen realisiert. Die wichtigsten Konstrukte dafür besprechen wir in diesem Video.

Diskussionen, Fragen und Antworten im Forum: https://community.hobbyelektroniker.ch/wbb/index.php?board/74

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



