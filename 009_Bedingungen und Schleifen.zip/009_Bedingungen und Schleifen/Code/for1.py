menge = (1,3,2,5,3) # Tupel
for x in menge:
    print(x)
    
print("----------")

menge = {1,3,2,5,3} # Set
for x in menge:
    print(x)
    
print("----------")

menge = [1,3,2,5,3] # List
for x in menge:
    print(x)
    
print("----------")

menge = [1,3,2,5,3]
for x in menge:
    print(x)
    if x == 3: break
    
print("----------")

menge = "Hallo"
for x in menge:
    print(x)

print("----------")

menge = range(2,10)
for x in menge:
    print(x)
    
print("----------")

menge = range(2,10,2)
for x in menge:
    print(x)
    
print("----------")

menge = range(10,2,-2)
for x in menge:
    print(x)
    
print("----------")


