x = 4
print("Die Zahl {}".format(x))
if x < 5:
    print(" ist kleiner als 5")
    
print("-------")

x = 6
print("Die Zahl {}".format(x))
if x < 5:
    print(" ist kleiner als 5")
else:
    print(" ist grösser als 5")
    
    
print("-------")

x = 5
print("Die Zahl {}".format(x))
if x < 5:
    print(" ist kleiner als 5")
elif x == 5:
    print(" ist exakt 5")
else:
    print(" ist grösser als 5")
    
print("-------")

x = 6
print("Die Zahl {}".format(x))
if x > 5: print(" ist grösser als 5") 
    
print("-------")

x = 8
print("Die Zahl {}".format(x))
if x >= 5 and x <= 10 : print(" liegt zwischen 5 und 10") 
    


