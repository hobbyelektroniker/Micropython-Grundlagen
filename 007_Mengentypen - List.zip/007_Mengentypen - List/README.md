# Micropython Grundlagen 7 - Mengentypen: List
 
https://youtu.be/SK95zQCH2sw

Eine List ist wie ein Tuple, hat aber noch die Möglichkeit seine Werte zu verändern. Diese Liste funktioniert ähnlich wie ein Array, kann aber verschiedene Datentypen enthalten.

Diskussionen, Fragen und Antworten im Forum: https://community.hobbyelektroniker.ch/wbb/index.php?board/64

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



