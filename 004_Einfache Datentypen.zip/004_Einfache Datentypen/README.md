# Micropython Grundlagen - 4: Einfache Datentypen
 
https://youtu.be/HQNJiIl-z3c

Micropython behandelt Datentypen recht unkompliziert. Trotzdem sollte man sie kennen, damit man bei Bedarf korrigierend eingreifen kann.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/62

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



