# Micropython Grundlagen 8 - Mengentypen: Dictionary
 
https://youtu.be/IWS7C_VE-xQ

Das Dictionary ist der leistungsfähigste Mengentyp. Er ist indexiert wie die List, verwendet aber als Index einen beliebigen Begriff.

Diskussionen, Fragen und Antworten im Forum: https://community.hobbyelektroniker.ch/wbb/index.php?board/64

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



