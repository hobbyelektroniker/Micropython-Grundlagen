# Micropython Grundlagen - 2: Kommentare, Blöcke und Operatoren
 
https://youtu.be/9ZV9u7Up6qE

Kommentare, Programmblöcke und Operatoren sind wichtige Bestandteile jeder Programmiersprache. Wie das in Python funktioniert, lernst du in dieser Lektion.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/52

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



