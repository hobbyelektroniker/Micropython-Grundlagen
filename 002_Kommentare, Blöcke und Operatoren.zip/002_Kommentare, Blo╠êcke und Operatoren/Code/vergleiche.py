print("Vergleiche")
a = 6
b = 7
c = 6
print("a =",a)
print("b =",b)
print("c =",c)
print()

print("a == b =",a == b)
print("a == c =",a == c)
print("a != b =",a != b)
print()

print("a < b  =",a < b)
print("a > b  =",a > b)
print("a < c  =",a < c)
print("a <= c =",a <= c)
print("a >= c =",a >= c)
print()

a = (1,3,4,5)
print("a =",a)
print()

print("2 in a =",2 in a)
print("3 in a =",3 in a)
print("2 not in a =",2 not in a)
