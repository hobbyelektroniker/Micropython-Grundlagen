# Kommentare

"""
Das ist einfach ein
mehrzeiliger Kommentar
"""

text1 = """
Wir beschäftigen uns
hier mit Kommentaren
"""

text2 = '''
Wir beschäftigen uns
hier mit Kommentaren
'''


print("Start")
print(text1)
print(text2)
print("Ende")

