print("Arithmetische Operatoren")
a = 11
b = 3
print("a =",a)
print("b =",b)
print()

print("a + b =",a + b)
print("a - b =",a - b)
print("a * b =",a * b)
print("a / b =",a / b)
print()

print("a // b =",a // b)  # ganzzahlige Division
print("a % b =",a % b)    # Modulo (Rest einer Division)
print("a ** b =",a ** b)  # Exponent (a hoch b)

print("Wurzel von 9 =",9**(1/2))


