print("Logische Operatoren")
a = True
b = False
print("a =",a)
print("b =",b)
print()

print("a and b =",a and b) # beide Elemente müssen True sein
print("a or b =",a or b)   # mindestens ein Element muss True sein
print("not a =",not a)     # aus True wird False und umgekehrt

