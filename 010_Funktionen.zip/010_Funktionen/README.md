# Micropython Grundlagen 10: Funktionen
 
https://youtu.be/1PHV8IyqkQE

Funktionen sind ein wichtiger Bestandteil jeder Programmiersprache. Python bietet spezielle Möglichkeiten bezüglich der Übergabe der Argumente und Rückgabe der Resultate.

Diskussionen, Fragen und Antworten im Forum: https://community.hobbyelektroniker.ch/wbb/index.php?board/76

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



